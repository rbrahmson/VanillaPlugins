jQuery(document).ready(function() {
   $.get(gdn.url('/plugin/feeddiscussions/checkfeeds'));
});